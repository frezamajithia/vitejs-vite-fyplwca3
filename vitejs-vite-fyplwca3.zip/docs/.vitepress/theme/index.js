import DefaultTheme from 'vitepress/theme';
import './index.css';

console.log('>>> Custom theme loaded! <<<');

export default {
  ...DefaultTheme,
};
