// docs/.vitepress/config.js
export default {
  title: 'PaperBeam',
  description: 'Now with FlexText!',
  themeConfig: {
    logo: '/logo.png', // Place logo.png in docs/.vitepress/public/logo.png
    siteTitle: 'PaperBeam', // optional text next to the logo

    nav: [
      { text: 'Products', link: '/products' },
      { text: 'API', link: '/api' },
      {
        text: 'Learning',
        items: [
          { text: 'Docs', link: '/learning/docs' },
          { text: 'Guide', link: '/learning/guide' },
          { text: 'Overview', link: '/learning/overview' },
        ],
      },
      { text: 'Contact', link: '/contact' },
    ],
    sidebar: [
      {
        text: 'Overview',
        items: [
          { text: 'Home', link: '/' },
          { text: 'Products', link: '/products' },
          { text: 'API', link: '/api' },
          { text: 'Contact', link: '/contact' },
        ],
      },
      {
        text: 'Learning',
        items: [
          { text: 'Docs', link: '/learning/docs' },
          { text: 'Guide', link: '/learning/guide' },
          { text: 'Overview', link: '/learning/overview' },
        ],
      },
    ],
  },
};
