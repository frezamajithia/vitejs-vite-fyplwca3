---
layout: home
hero:
  name: "PaperBeam"
  text: "Now with FlexText"
  tagline: "Elevate Your Content Flow"
  image:
    src: /logo.png   # Place your 3D PB icon or hero image in .vitepress/public/logo.png
    alt: "PaperBeam 3D Logo"
  actions:
    - theme: brand
      text: "Product Description"
      link: /products
    - theme: alt
      text: "Reference"
      link: /api
features:
  - icon: 🏆
    title: "Adaptive Columns"
    details: "Dynamically adjust column count and layout on the fly"
  - icon: 🌟
    title: "Editorial Curation"
    details: "Seamlessly merge media and text into a curated feed"
  - icon: 👥
    title: "User Driven Community"
    details: "Used in over 60 countries worldwide"
---
